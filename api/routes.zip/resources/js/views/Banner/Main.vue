<template>
    <router-view />
</template>